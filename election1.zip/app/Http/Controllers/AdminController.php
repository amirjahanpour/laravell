<?php

namespace App\Http\Controllers;

use App\Models\AdminModels;
use App\Models\cities;
use App\Models\provinces;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class AdminController extends Controller
{
//    public function donlwodimg($imgid){
//      return dd($imgpath);
//      //  $food=AdminModels::find($imgpath);
//       // return Storage::download($food->img);
//    }
    public function delete($id){
        $food=AdminModels::find($id);
        if (AdminModels::destroy($id)){
            Storage::delete('public/'.$food->img);
            $message='<div class="alert alert-secondary">حذف با موفقیت انجام شد</div>';
        }else{
            $message='<div class="alert alert-light">حذف ناموفق بود</div>';
        }
        return $this->index($message);
    }

    public function update(Request $request,$id){
        $validated = $request->validate([
            'name' => 'required|String|min: 1|max:255',
            'state' => 'required|String|min: 1|max:100',
            'city' => 'required|String|min: 1|max:100',
            'mobile' => 'nullable|numeric|min: 1',
            'phone' => 'nullable|numeric|min: 1',
            'resume' => 'nullable|String|min: 1|max:2000',
            'img' => 'nullable|image',
        ]);
        try {
            $fd= AdminModels::find($id);
            $fd->name=$request->input('name');
            $fd->state=$request->input('state');
            $fd->city=$request->input('city');
            $fd->mobile=$request->input('mobile');
            $fd->phone=$request->input('phone');
            $fd->resume=$request->input('resume');
            if ($request->hasFile('img')) {
                $phat = $request->file('img')->storeAs('img', $fd->id . '.' . $request->file('img')->extension());
                $fd->img = $phat;
                $fd->save();
                Storage::move($phat, 'public/'.$phat);
            }
            $statename = DB::table('provinces')
                ->where('id', '=', $fd->state)
                ->get();
            foreach ($statename as $user) {
                $fd->namecities = $user->name;
            }
            $citynew = DB::table('cities')
                ->where('id', '=', $fd->city)
                ->get();
            foreach ($citynew as $citynews) {
                $fd->namecity = $citynews->name;
            }
            $fd->save();
            return $this->edit( $fd->id,'editok');
        } catch (Exception $exception){
            return $this->edit($fd->id,'editnotok');
        }
    }
    public function edit($id,$message=''){
        $allprovinces=provinces::all();
        $allcities=cities::all();
        $editform=AdminModels::find($id);
        return view('create.form',['message'=>$message,'editform'=>$editform,'provinces'=>$allprovinces,'cities'=>$allcities]);
    }

    public function index($message = ' '){
        $alluser=AdminModels::paginate(9);
        return view('create.list',['user'=>$alluser,'message'=>$message]);
    }
    public function create($ans=' '){
        $allprovinces=provinces::all();
        $allcities=cities::all();
        return view('create.form',['message'=>$ans,'provinces'=>$allprovinces,'cities'=>$allcities]);
    }
    public function received(Request $request){
            $validated = $request->validate([
            'name' => 'required|String|min: 1|max:255',
            'state' => 'required|String|min: 1|max:100',
            'city' => 'required|String|min: 1|max:100',
            'resume' => 'nullable|String|min: 1|max:2000',
            'mobile' => 'nullable|numeric|min: 1',
            'phone' => 'nullable|numeric|min: 1',
            'img' => 'nullable|image',
        ]);
        try {
            $fd=new AdminModels();
            $fd->name=$request->input('name');
            $fd->state=$request->input('state');
            $fd->city=$request->input('city');
            $fd->mobile=$request->input('mobile');
            $fd->phone=$request->input('phone');
            $fd->resume=$request->input('resume');
            $fd->save();
            $statename = DB::table('provinces')
                ->where('id', '=', $fd->state)
                ->get();
            foreach ($statename as $user) {
                $fd->namecities = $user->name;
                $fd->save();
            }
            $citynew = DB::table('cities')
                ->where('id', '=', $fd->city)
                ->get();
            foreach ($citynew as $citynews) {
                $fd->namecity = $citynews->name;
                $fd->save();
            }
            if ($request->hasFile('img')) {
                $phat = $request->file('img')->storeAs('img', $fd->id . '.' . $request->file('img')->extension());
                Storage::move($phat, 'public/' . $phat);
                $fd->img = $phat;
            }
            $fd->save();
            return $this->create('saveok');
        } catch (Exception $exception){
            //return $exception->getMessage();
            return $this->create('savenotok');
        }
    }

}
