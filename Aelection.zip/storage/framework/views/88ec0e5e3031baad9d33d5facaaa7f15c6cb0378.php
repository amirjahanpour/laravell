<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مشخصات</title>
    <link rel="stylesheet" type="text/css" href=<?php echo e(asset('asset/css/bootstrap-rtl.css')); ?>>
    <link rel="stylesheet" type="text/css" href=<?php echo e(asset('asset/css/bootstrap.min.css')); ?>>
    <link rel="stylesheet" type="text/css" href=<?php echo e(asset('asset/css/fontawesome-all.min.css')); ?>>
    <link rel="stylesheet" type="text/css" href=<?php echo e(asset('asset/css/iofrm-style.css')); ?>>
    <link rel="stylesheet" type="text/css" href=<?php echo e(asset('asset/css/iofrm-theme12.css')); ?>>
    <link rel="stylesheet" media="screen" href=<?php echo e(asset('list/css/nicepage.css')); ?> >
    <link rel="stylesheet" media="screen" href=<?php echo e(asset('list/css/Contact.css')); ?> >
</head>
<body>
<div class="form-body" class="container-fluid">
    <div class="row">
        <div class="form-holder">
            <div class="form-content">
                <?php if(session()->has("msg")): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get("msg")); ?>

                    </div>
                <?php endif; ?>
                <div class="form-items">
                    <div class="u-nav-container">
                        <?php $__currentLoopData = \App\Models\AdminMenu::$menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kay=>$menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul class="u-nav u-unstyled u-nav-1">
                                <li class="u-nav-item colorlink"><a
                                            class="u-button-style u-nav-link u-text-active-palette-1-base u-text-hover-palette-2-base"
                                            href="<?php echo e(url($menu)); ?>" style="padding: 10px 20px;"><?php echo e($kay); ?></a></li>
                            </ul>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <form action="<?php echo e(url('logout')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input style=" background-color: #152733; width: auto; text-align: inherit; color: white;"
                                       type="submit" value="خروج">
                            </form>
                        </div>
                    </div>
                    <?php if(isset($editform)): ?>
                        <p>لطفا اطلاعات زیرا ویرایش کنید</p>
                        <p>:تصویر فعلی شما</p>
                    <?php endif; ?>
                    <?php if(!isset($editform)): ?>
                        <h3>سلام</h3>
                        <p>لطفا فرم زیرا تکمیل کنید</p>
                    <?php endif; ?>
                    <?php if($message=='saveok'): ?>
                        <div class="alert alert-success">
                            ثبت با موفقیت ایچاد شد
                        </div>
                    <?php elseif($message=='savenotok'): ?>
                        <div class="alert alert-danger">
                            مشکل در ثبت
                        </div>
                    <?php elseif($message=='editok'): ?>
                        <div class="alert alert-success">
                            ویرایش با موفقیت انجام شد
                        </div>
                    <?php elseif($message=='editnotok'): ?>
                        <div class="alert alert-danger">
                            مشکل در ویرایش
                        </div>
                    <?php endif; ?>
                    <form action="<?php if(isset($editform)): ?><?php echo e(url('/update/'.$editform->id)); ?><?php else: ?><?php echo e(url('/create')); ?><?php endif; ?>"
                          method="post" enctype="multipart/form-data">
                        <?php if(isset($editform)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <?php if(isset($editform)): ?>
                            <img src="<?php echo e(asset('/storage/'.$editform['img'])); ?>" class="img-thumbnail">
                            :عکس قبلی
                        <?php endif; ?>
                        <div class="form-group">
                            <label>نام و نام خانوادگی</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($editform['name'] ?? ''); ?>"
                                   placeholder="نام" style="text-align: end; font-weight: bold;">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>استان و شهر</label>
                            <div class="form-row">
                                <div class="col">
                                    <select name="state" style="text-align-last: center;"
                                            class="form-select form-select-lg mb-1" onChange="iranwebsv(this.value);">
                                        <option value="0">لطفا استان را انتخاب نمایید</option>
                                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($province->id); ?>"><?php echo e($province->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <select name="city" style="text-align-last: center;"
                                            class="form-select form-select-sm" onChange="iranwebsv(this.value);">
                                        <option value="0">لطفا شهر را انتخاب نمایید</option>
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($citie->id); ?>"><?php echo e($citie->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div>
                            <label>عکس خود را وارد کنید</label>
                            <div>
                                <input type="file" class="form-control text-align: end;" name="img">
                            </div>
                            <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>شماره همراه</label>
                            <input type="text" class="form-control" name="mobile"
                                   value="<?php echo e($editform['mobile'] ?? ''); ?>" placeholder="تلفن همراه"
                                   style="text-align: end; font-weight: bold;">
                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="text" class="form-control" name="phone" value="<?php echo e($editform['phone'] ?? ''); ?>"
                                   placeholder="تلفن ثابت" style="text-align: end; font-weight: bold;">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>توضیحات و رزومه</label>
                            <textarea class="form-control" name="resume"
                                      style="text-align: end; font-weight: bold;"><?php echo e($editform['resume'] ?? ''); ?></textarea>
                            <?php $__errorArgs = ['resume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-button text-right">
                            <button id="submit" type="submit" class="ibtn">ثبت</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src=<?php echo e(asset('asset/js/jquery.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('asset/js/city.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('asset/js/popper.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('asset/js/bootstrap.min.js')); ?>></script>
<script type="text/javascript" src=<?php echo e(asset('asset/js/main.js')); ?>></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\election\resources\views/create/form.blade.php ENDPATH**/ ?>