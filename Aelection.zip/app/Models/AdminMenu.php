<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AdminMenu extends Model
{
    use HasFactory;
    public static $menu=[
        'مشاهده کاربرا'=>'/',
        'اضافه کردن کاربر'=>'/create',
    ];
}
